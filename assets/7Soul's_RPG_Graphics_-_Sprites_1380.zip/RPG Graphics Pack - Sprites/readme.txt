7Soul's RPG Graphics - Sprites Pack
by 7Soul - @7SoulDesign
http://7soul1.deviantart.com/

License(CC BY-ND 4.0)

You may use this content in free or commercial works
You must give credits (to Henrique Lazarini or 7Soul)
You may not distribute derivatives of this material (aka edit the assets and resell)

v1.2
- Added player sprites facing sideways

v1.1
Player Sprites:
- Added direction "up"

Other:
- Added Chest sprites
- Added Door sprites

v1.0
Player Sprites:
- 20 Heads (with 4 color variations)
- 15 Bodies (with 4 color variations)
- 15 Full sprites (with 4 color variations)

Monster Sprites:
- 34 Monsters (with 3 color variations)